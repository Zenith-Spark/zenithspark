export const NavItems = [
    {name:'HOME'},
    {name:'ABOUT US'},
    {name:'FAQ'},
    {name:'BONUSES'}
]